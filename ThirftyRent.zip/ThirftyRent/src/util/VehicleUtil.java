package util;

import java.text.SimpleDateFormat;

public class VehicleUtil {

	/*
	 * This static method is to generate vehicleID for new car or new van.
	 */
	public static String generateID(String vehicleType) {
		String ID = null;
		Long var = null;
		if (vehicleType == "car") {
			ID = "C_";
		} else {
			ID = "V_";
		}
		SimpleDateFormat sdf = new SimpleDateFormat("hmsS");
		var = System.currentTimeMillis();
		String addVar = sdf.format(var);
		ID = ID.concat(addVar);
		return ID;
	}
	
	
}
