package controller;

import exceptions.RentalException;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import main.ThriftyRentSystem;
import util.DateTime;


/*
 * This controller is called when the user selects rent vehicle
 */
public class RentVehicleController implements EventHandler<ActionEvent>{

	private Stage dialogBox;
	private String vehicleID;
	
	
	public RentVehicleController(Stage dialogBox,String vehicleID) {
		this.dialogBox=dialogBox;
		this.vehicleID=vehicleID;
		
	}
	@Override
	public void handle(ActionEvent event) {
		Scene scene = dialogBox.getScene();
		Stage stg=(Stage)scene.getWindow();
	
		try {
		TextField customerIDField = (TextField) scene.lookup("#customerID");
		TextField rentDateField = (TextField) scene.lookup("#rentDate");
		TextField days = (TextField) scene.lookup("#days");
		
		if(days.getText().trim().isEmpty() || customerIDField.getText().trim().isEmpty()) {
			throw new RentalException("Missing values....please enter all the required fields");
		}
		
		int noOfDays=Integer.parseInt(days.getText());
		String vehicleID=this.vehicleID;
		String customerID=customerIDField.getText().toUpperCase();
		String rentDate=rentDateField.getText().trim();
		DateTime rDate = new DateTime(rentDate);
		
		ThriftyRentSystem trs=new ThriftyRentSystem();
		trs.rentVehicle(vehicleID,customerID, rDate, noOfDays);
		
		Platform.runLater(() -> {
	        Alert dialog = new Alert(AlertType.INFORMATION, "Vehicle has been Rented", ButtonType.OK);
	        dialog.show();
	    });
		stg.close();
		}
		catch(RentalException e) {
			e.printStackTrace();
			Platform.runLater(() -> {
		        Alert dialog = new Alert(AlertType.ERROR, e.getMessage(), ButtonType.OK);
		        dialog.show();
		    });
			dialogBox.close();
		}
		catch(Exception e) {
			e.printStackTrace();
			Platform.runLater(() -> {
		        Alert dialog = new Alert(AlertType.ERROR, e.getMessage(), ButtonType.OK);
		        dialog.show();
		    });
			dialogBox.close();
		}
	}

}
