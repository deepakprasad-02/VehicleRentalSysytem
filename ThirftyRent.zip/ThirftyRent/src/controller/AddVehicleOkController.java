package controller;

import bean.VehicleBean;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

import javafx.scene.control.ButtonType;

import javafx.scene.control.TextField;

import javafx.stage.Stage;
import services.Car;
import services.Van;
import util.DateTime;


/*
 * This class is called upon when user clicks confirm for adding a vehicle
 * 
 */
public class AddVehicleOkController implements EventHandler<ActionEvent>{
	private Stage dialogBox;
	
	public AddVehicleOkController(Stage dialogBox) {
		this.dialogBox=dialogBox;
	}

	@Override
	public void handle(ActionEvent event) {
		Scene scene = dialogBox.getScene();
		Stage stg=(Stage)scene.getWindow();
		VehicleBean bean=new VehicleBean();
		Car car;
		Van van;
		
		TextField yearField = (TextField) scene.lookup("#year");
		TextField model = (TextField) scene.lookup("#model");
		TextField make = (TextField) scene.lookup("#make");
		TextField numOfSeats = (TextField) scene.lookup("#numOfSeats");
		TextField vehicleType = (TextField) scene.lookup("#vehicleType");
		TextField vehicleID = (TextField) scene.lookup("#vehicleID");
		TextField lastMaintDate = (TextField) scene.lookup("#lastMaintDate");
		
		try {
		int year=Integer.parseInt(yearField.getText());
		int noOfSeats=Integer.parseInt(numOfSeats.getText());
		bean.setVehicleID(vehicleID.getText().toUpperCase());
		bean.setYear(year);
		bean.setMake(make.getText());
		bean.setModel(model.getText());
		bean.setNoOfSeats(noOfSeats);
		DateTime date = new DateTime(lastMaintDate.getText());
		bean.setLastMaintDate(date);
		
		
		if(yearField.getText().trim().isEmpty() || make.getText().trim().isEmpty() || model.getText().trim().isEmpty() || vehicleType.getText().trim().isEmpty()
						|| lastMaintDate.getText().trim().isEmpty()) {
			throw new Exception("Missing values....please enter all the values");
		}
		else if(vehicleType.getText().equalsIgnoreCase("car")){
			car=new Car();
			car.validateAndAddCar(bean);
		}
		else if(vehicleType.getText().equalsIgnoreCase("van")) {
			van=new Van();
			van.validateAndAddVan(bean);
		}else {
			throw new Exception("Invalid values entered..");
		}
		
		Platform.runLater(() -> {
	        Alert dialog = new Alert(AlertType.INFORMATION, "Vehicle has been succesfully created", ButtonType.OK);
	        dialog.show();
	    });
		stg.close();
		}
		catch(NumberFormatException e) {
			e.printStackTrace();
			Platform.runLater(() -> {
		        Alert dialog = new Alert(AlertType.ERROR, "Required fields are missing", ButtonType.OK);
		        dialog.show();
		    });
			dialogBox.close();
		}
		catch(Exception e) {
			e.printStackTrace();
			Platform.runLater(() -> {
		        Alert dialog = new Alert(AlertType.ERROR, e.getMessage(), ButtonType.OK);
		        dialog.show();
		    });
			dialogBox.close();
		}
	}

}
