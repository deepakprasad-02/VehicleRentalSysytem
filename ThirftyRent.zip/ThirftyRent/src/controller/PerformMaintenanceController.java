package controller;

import exceptions.RentalException;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import main.ThriftyRentSystem;

public class PerformMaintenanceController implements EventHandler<ActionEvent>{
	Stage dialogBox;
	String vehicleID;
	
	public PerformMaintenanceController(Stage dialogBox, String vehicleID) {
		this.dialogBox=dialogBox;
		this.vehicleID=vehicleID;
	}

	@Override
	public void handle(ActionEvent event) {
		Scene scene = dialogBox.getScene();
		Stage stg=(Stage)scene.getWindow();
	
		try {
		
		
		ThriftyRentSystem trs=new ThriftyRentSystem();
		trs.performMaint(vehicleID);
		
		Platform.runLater(() -> {
	        Alert dialog = new Alert(AlertType.INFORMATION, "Vehicle is in maintenance now", ButtonType.OK);
	        dialog.show();
	    });
		stg.close();
		}
		catch(RentalException e) {
			e.printStackTrace();
			Platform.runLater(() -> {
		        Alert dialog = new Alert(AlertType.ERROR, e.getMessage(), ButtonType.OK);
		        dialog.show();
		    });
			dialogBox.close();
		}
		catch(Exception e) {
			e.printStackTrace();
			Platform.runLater(() -> {
		        Alert dialog = new Alert(AlertType.ERROR, e.getMessage(), ButtonType.OK);
		        dialog.show();
		    });
			dialogBox.close();
		}
	}
}
