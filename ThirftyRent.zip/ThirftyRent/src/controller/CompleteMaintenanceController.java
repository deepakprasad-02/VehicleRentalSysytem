package controller;

import exceptions.RentalException;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import main.ThriftyRentSystem;
import util.DateTime;

public class CompleteMaintenanceController implements EventHandler<ActionEvent>{
	Stage dialogBox;
	String vehicleID;
	
	public CompleteMaintenanceController(Stage dialogBox, String vehicleID) {
		this.dialogBox=dialogBox;
		this.vehicleID=vehicleID;
	}

	@Override
	public void handle(ActionEvent event) {
		Scene scene = dialogBox.getScene();
		Stage stg=(Stage)scene.getWindow();
	
		try {
		TextField CompleteDateField = (TextField) scene.lookup("#completionDate");		
		if(CompleteDateField.getText().trim().isEmpty()) {
			throw new RentalException("Please provide the completion date");
		}
		String completeDate=CompleteDateField.getText().trim();
		DateTime cDate = new DateTime(completeDate);
		
		ThriftyRentSystem trs=new ThriftyRentSystem();
		trs.completeMaint(vehicleID,cDate);
		
		Platform.runLater(() -> {
	        Alert dialog = new Alert(AlertType.INFORMATION, "Vehicle maintenance is complete", ButtonType.OK);
	        dialog.show();
	    });
		stg.close();
		}
		catch(RentalException e) {
			e.printStackTrace();
			Platform.runLater(() -> {
		        Alert dialog = new Alert(AlertType.ERROR, e.getMessage(), ButtonType.OK);
		        dialog.show();
		    });
			dialogBox.close();
		}
		catch(Exception e) {
			e.printStackTrace();
			Platform.runLater(() -> {
		        Alert dialog = new Alert(AlertType.ERROR, e.getMessage(), ButtonType.OK);
		        dialog.show();
		    });
			dialogBox.close();
		}
	}
}
