package view;


import controller.AddVehicleOkController;
import controller.DialogCancelController;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

/*
 * This class is used to accept the details of a new car
 * 
 */
public class AddVehicleView implements EventHandler<ActionEvent>{

	@Override
	public void handle(ActionEvent event) {	
		
		Stage dialogBox = new Stage();
		dialogBox.initModality(Modality.APPLICATION_MODAL);
		dialogBox.setTitle("Car entry dialog box");
		
		
		// dialog components
		Label vidLabel=new Label("Vehicle ID");
		TextField vehicleIDField = new TextField();
		vehicleIDField.setPromptText("Optional");
		vehicleIDField.setId("vehicleID");
		
		Label yearLabel=new Label("Year");
		TextField yearField = new TextField();
		yearField.setPromptText("YYYY");
		yearField.setId("year");
		
		Label makeLabel=new Label("Make");
		TextField makeField = new TextField();
		makeField.setPromptText("Name of the comapny");
		makeField.setId("make");
		
		Label modelLabel=new Label("Model");
		TextField modelField = new TextField();
		modelField.setPromptText("Model");
		modelField.setId("model");

		Label vTypeLabel=new Label("Vehicle Type");
		TextField vTypeField = new TextField();
		vTypeField.setPromptText("Car or Van");
		vTypeField.setId("vehicleType");

		Label numSeatsLabel=new Label("Number of Seats");
		TextField numSeatsField = new TextField();
		numSeatsField.setPromptText("4 or 7 for car | 15 for van");
		numSeatsField.setId("numOfSeats");
		
		Label lastLabel=new Label("Last Maintenance date");
		TextField lastMaintDateField = new TextField();
		lastMaintDateField.setPromptText("DD/MM/YYYY");
		lastMaintDateField.setId("lastMaintDate");


		Button dialogOKButton = new Button("OK");
		Button dialogCancelButton = new Button("Cancel");
		
		HBox dialogButtons = new HBox();
		dialogButtons.getChildren().add(dialogCancelButton);
		dialogButtons.getChildren().add(dialogOKButton);
		dialogButtons.setAlignment(Pos.CENTER);

		
		
		
		// layout the dialog components
		VBox dialogVBox = new VBox();
		dialogVBox.getChildren().add(vidLabel);
		dialogVBox.getChildren().add(vehicleIDField);
		dialogVBox.getChildren().add(yearLabel);
		dialogVBox.getChildren().add(yearField);
		dialogVBox.getChildren().add(makeLabel);
		dialogVBox.getChildren().add(makeField);
		dialogVBox.getChildren().add(modelLabel);
		dialogVBox.getChildren().add(modelField);
		dialogVBox.getChildren().add(vTypeLabel);
		dialogVBox.getChildren().add(vTypeField);
		dialogVBox.getChildren().add(numSeatsLabel);
		dialogVBox.getChildren().add(numSeatsField);
		dialogVBox.getChildren().add(lastLabel);
		dialogVBox.getChildren().add(lastMaintDateField);
		dialogVBox.getChildren().add(dialogButtons);
		
		

		
		Scene dialogScene = new Scene(dialogVBox, 400, 600);
		dialogBox.setScene(dialogScene);
		dialogOKButton.setOnAction(new AddVehicleOkController(dialogBox));
		dialogCancelButton.setOnAction(new DialogCancelController(dialogBox));
		dialogBox.showAndWait();
		
		
		
		
	}

}
