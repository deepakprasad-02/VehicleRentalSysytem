package view;

import java.util.ArrayList;
import java.util.List;

import bean.RentalRecordBean;
import bean.VehicleBean;
import controller.DialogCancelController;
import controller.ExportController;
import controller.ImportController;
import controller.QuitButtonController;
import dao.RentalDB;
import exceptions.RentalDBException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import util.DateTime;

public class VehicleDetailView{
	
	
	@SuppressWarnings("unchecked")
	public static void  detailView(VehicleBean vBean) {
		Stage stg=new Stage();
        Menu m = new Menu("Menu"); 
  
        // create menuitems
		
		 MenuItem m1 = new MenuItem("Import to DB"); 
	        MenuItem m2 = new MenuItem("Export to File"); 
	        MenuItem m3 = new MenuItem("Quit"); 
	  
	        // add menu items to menu 
	        m.getItems().add(m1); 
	        m.getItems().add(m2); 
	        m.getItems().add(m3); 
	  
	     
	  
	        // add event 
	        m1.setOnAction(new ImportController()); 
	        
	       m2.setOnAction(new ExportController()); 
	        m3.setOnAction(new QuitButtonController(stg)); 
	  
	        // create a menubar 
	        MenuBar mb = new MenuBar(); 
	  
	        // add menu to menubar 
	        mb.getMenus().add(m);
	        VBox vb = new VBox(mb); 
	        
	        RentalDB rdb=new RentalDB();
			List<RentalRecordBean> rList = null;
			try {
				rList = rdb.getAllRentalRecords();
			} catch (RentalDBException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			List<RentalRecordBean> rTempList=new ArrayList<>();
			for(RentalRecordBean r : rList) {
				if(r.getRecordID().startsWith(vBean.getVehicleID())) {
					rTempList.add(r);
				}
			}
			ObservableList<RentalRecordBean> list = FXCollections.observableArrayList(rTempList);
	      //  ListView<RentalRecordBean> lv = new ListView<>(list);
			
			//HBox h1Box=new HBox();
			//Rental Record column
	        TableColumn<RentalRecordBean, String> recordIDColumn = new TableColumn<>("Rental Record Number");
	        recordIDColumn.setMinWidth(200);
	        recordIDColumn.setCellValueFactory(new PropertyValueFactory<>("recordID"));

	        //Rent Date column
	        TableColumn<RentalRecordBean, DateTime> rentDateColumn = new TableColumn<>("Rent Date");
	        rentDateColumn.setMinWidth(100);
	        rentDateColumn.setCellValueFactory(new PropertyValueFactory<>("rentDate"));

	        //Estimated return date column
	        TableColumn<RentalRecordBean, DateTime> estimatedReturnDateColumn = new TableColumn<>("Estimated Return Date");
	        estimatedReturnDateColumn.setMinWidth(100);
	        estimatedReturnDateColumn.setCellValueFactory(new PropertyValueFactory<>("estimatedReturnDate"));
	        
	        //Actual return date column
	        TableColumn<RentalRecordBean, DateTime> actualReturnDateColumn = new TableColumn<>("Actual Return Date");
	        actualReturnDateColumn.setMinWidth(100);
	        actualReturnDateColumn.setCellValueFactory(new PropertyValueFactory<>("actualReturnDate"));

	        
	        //Rent fee column
	        TableColumn<RentalRecordBean, Double> rentFeeColumn = new TableColumn<>("Rent Fee");
	        rentFeeColumn.setMinWidth(100);
	        rentFeeColumn.setCellValueFactory(new PropertyValueFactory<>("rentalFee"));

	        
	        //Late fee column
	        TableColumn<RentalRecordBean, Double> lateFeeColumn = new TableColumn<>("Late Fee");
	        lateFeeColumn.setMinWidth(100);
	        lateFeeColumn.setCellValueFactory(new PropertyValueFactory<>("lateFee"));


	        TableView<RentalRecordBean> table = new TableView<>();
	        table.setItems(list);
	        table.getColumns().addAll(recordIDColumn, rentDateColumn, estimatedReturnDateColumn, actualReturnDateColumn, rentFeeColumn, lateFeeColumn);

	        VBox vBox = new VBox();
	        vBox.getChildren().addAll(table);

		
		Button rentVehicleButton=new Button("Rent Vehicle");
		Button returnVehicleButton=new Button("Return Vehicle");
		Button performMaintButton=new Button("Perform Maintenance");
		Button completeMaintButton=new Button("Complete Maintenance");
		
		
		Button quitButton = new Button("Back");
		HBox hBox = new HBox(); 
		hBox.setAlignment(Pos.CENTER);
		//hBox.getChildren().add(addVehicleButton);
		if(vBean.getVehicleStatus().equalsIgnoreCase("Available")) {
			hBox.getChildren().add(rentVehicleButton);
			hBox.getChildren().add(performMaintButton);
		}else if(vBean.getVehicleStatus().equalsIgnoreCase("Rented")) {
			hBox.getChildren().add(returnVehicleButton);
		}else {
			hBox.getChildren().add(completeMaintButton);
		}
		hBox.setSpacing(5);
		hBox.getChildren().add(quitButton);
		
		//rent vehicle
		rentVehicleButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
            	RentVehicleView.rentVehicle(vBean.getVehicleID());
            }
        });
		
		//return vehicle
		returnVehicleButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
            	ReturnVehicleView.returnVehicle(vBean.getVehicleID());
            }
        });
		
		//return vehicle
		performMaintButton.setOnAction(new EventHandler<ActionEvent>() {
		    @Override
		     public void handle(ActionEvent event) {
		            	PerformMaintenanceView.perfMaintVehicle(vBean.getVehicleID());
		            }
		        });
		
		completeMaintButton.setOnAction(new EventHandler<ActionEvent>() {
		    @Override
		     public void handle(ActionEvent event) {
		            	CompleteMaintenanceView.completeMaintVehicle(vBean.getVehicleID());
		            }
		        });
		
		
				
				
		//returnVehicleButton.setOnAction();
		quitButton.setOnAction(new DialogCancelController(stg));
		
		
        
		
		BorderPane borderPane = new BorderPane();
		borderPane.setBottom(hBox);
		borderPane.setCenter(vBox);
		borderPane.setTop(vb);
		BorderPane.setAlignment(hBox, Pos.CENTER);
		Scene bScene = new Scene(borderPane, 600, 600);
		
		stg.setTitle("Vehicle Detail Screen"); // Set the stage title
		stg.setScene(bScene); // Place the scene in the stage
		
		stg.show(); // Display the stage
	}
		
		
		
	

}
