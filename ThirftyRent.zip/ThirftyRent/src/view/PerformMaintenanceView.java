package view;

import controller.DialogCancelController;
import controller.PerformMaintenanceController;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class PerformMaintenanceView {
	public static void perfMaintVehicle(String vehicleID) {
		Stage dialogBox = new Stage();
		dialogBox.initModality(Modality.APPLICATION_MODAL);
		dialogBox.setTitle("vehicle Maintenance window");
		
		
		// dialog components
		Label vidLabel=new Label("Vehicle ID");
		TextField vehicleIDField = new TextField();
		vehicleIDField.setDisable(true);
		vehicleIDField.setStyle("-fx-opacity: 1.0;");
		//vehicleIDField.setEditable(false);
		vehicleIDField.setPromptText(vehicleID);
		vehicleIDField.setId("vehicleID");


		Button dialogConfirmButton = new Button("Confirm");
		Button dialogCancelButton = new Button("Cancel");
		
		HBox dialogButtons = new HBox();
		dialogButtons.setPadding(new Insets(10,10,10,10));
		dialogButtons.getChildren().add(dialogCancelButton);
		dialogButtons.getChildren().add(dialogConfirmButton);
		dialogButtons.setAlignment(Pos.CENTER);

		
		
		
		// layout the dialog components
		VBox dialogVBox = new VBox();
		dialogVBox.getChildren().add(vidLabel);
		dialogVBox.getChildren().add(vehicleIDField);
		dialogVBox.getChildren().add(dialogButtons);
		
		

		
		Scene dialogScene = new Scene(dialogVBox, 200, 300);
		dialogBox.setScene(dialogScene);
		dialogConfirmButton.setOnAction(new PerformMaintenanceController(dialogBox,vehicleID));
		dialogCancelButton.setOnAction(new DialogCancelController(dialogBox));
		dialogBox.showAndWait();
		
		
	}
}
