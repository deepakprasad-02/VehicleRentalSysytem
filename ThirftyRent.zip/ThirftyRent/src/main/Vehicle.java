package main;

import java.sql.SQLException;
import java.util.ArrayList;

import bean.RentalRecordBean;
import bean.VehicleBean;
import exceptions.RentalDBException;
import exceptions.RentalException;
import util.DateTime;

public abstract class Vehicle {
static ArrayList<VehicleBean> vehicleArray = new ArrayList<VehicleBean>(50);
static ArrayList<RentalRecordBean> rentalRecordArray = new ArrayList<RentalRecordBean>();
VehicleBean vBean = new VehicleBean();
RentalRecordBean rBean = new RentalRecordBean();
public void rent(String vehicleID,String customerId, DateTime rentDate, int numOfRentDay) throws RentalException, RentalDBException, SQLException{}
public void returnVehicle(String vehicleID,DateTime returnDate) throws RentalDBException, SQLException{}
public void performMaintenance(String vehicleID) throws SQLException{}
public void completeMaintenance(String vehicleID, DateTime completionDate) throws SQLException {}

/*
 * 
 * this method performs validation for current date
 */
public boolean validateCurrentDate(DateTime cDate) {
	boolean flag=false;
	DateTime tDate=new DateTime();
	int count=DateTime.diffDays(tDate, cDate);
	if(count>=0) {
		flag=true;
	}
	return flag;
}
}
