package main;


import java.io.File;
import java.sql.SQLException;
import java.util.List;

import bean.VehicleBean;
import dao.VehicleDB;
import exceptions.RentalDBException;
import exceptions.RentalException;
import services.Car;
import services.ImportData;
import services.Van;
import util.DateTime;


/*as per conversion with Dale, few of the scenarios in vehicle maintenance have been not
 * taken care
 */
public class ThriftyRentSystem{
	

	public void startUp() throws Exception {
		VehicleDB vdb=new VehicleDB();
		List<VehicleBean> vList=vdb.getVehicles();
		if(vList.size()==0) {
			ImportData.consumeFromFile(new File("resources/export_data.txt"));
		}
	}

	/*
	 * This method accepts input from user for rent functionality
	 * 
	 * 
	 */
	public void rentVehicle(String vehicleID,String customerID,DateTime rentDate,int noOfDays) throws RentalException, SQLException{
		Car car;
		Van van;
		VehicleDB vdb=new VehicleDB();
		try {
			boolean check = vdb.checkVehicleID(vehicleID);
			if(check==false) {
				throw new RentalException(vehicleID + " does not exsist!!\n\nPlease enter a valid Vehicle ID");
			}
			boolean statusCheck = ((vdb.getVehicleStatus(vehicleID)).equals("Available"));
			if (check && statusCheck) {
				if (customerID.trim().equals(null)) {
					throw new RentalException("Customer ID cannot be empty.");
				}
				if (vehicleID.contains("C_")) {
					car = new Car();
					car.rent(vehicleID,customerID, rentDate, noOfDays);
				} else {
					van = new Van();
					van.rent(vehicleID,customerID, rentDate, noOfDays);
				}
			} 
		}finally {
			
		}
	}

	/*
	 * 
	 * This method accepts user input for returning a vehicle
	 */
	public void returnVehicle(String vehicleID,DateTime returnDate) throws SQLException{

		boolean flag = false;
		Van van;
		Car car;
		String id=vehicleID;
		VehicleDB vdb=new VehicleDB();
		try {
			flag = vdb.checkVehicleID(vehicleID);
			if (flag==false) {
				throw new RentalDBException("Invalid vehicle ID entered for performing return");
			}
			String status = vdb.getVehicleStatus(id);
			if ((status.equals("Rented"))) {
				if (vehicleID.contains("C_")) {
					car=new Car();
					car.returnVehicle(vehicleID, returnDate);
				} else if(vehicleID.contains("V_")){
					van=new Van();
					van.returnVehicle(vehicleID, returnDate);
				}
			} else {
				throw new RentalDBException(vehicleID + " return did not happen\n");
			}
		}finally {	
		}
	}



	/*
	 * This method accepts user input for performing maintenance and validates the
	 * id
	 */
	public void performMaint(String vehicleID) throws Exception {
		String id=vehicleID;
		Car car;
		Van van;
		VehicleDB vdb=new VehicleDB();
		try {
		boolean flag = vdb.checkVehicleID(id);
		if (flag==false) {
			throw new Exception("Invalid vehicle ID entered for performing maintenance");
		}
		if ((vdb.getVehicleStatus(id).equals("Available"))) {
			if (id.contains("C_")) {
				car = new Car();
				car.performMaintenance(id);
			} else {
				van = new Van();
				van.performMaintenance(id);
			}
		}
		}finally {
		}
	}

	/*
	 * This method used to accept input for complete maintenance functionality It
	 * also validates for un-desired vehicle id provided by user
	 * 
	 */
	public void completeMaint(String vehicleID,DateTime cDate) throws Exception {
		Car car;
		Van van;
		String id =vehicleID;
		VehicleDB vdb=new VehicleDB();
		try {
		boolean flag = vdb.checkVehicleID(id);
		if (flag==false) {
			throw new Exception("Invalid vehicle ID entered for completing maintenance");
		}
		if ((vdb.getVehicleStatus(id).equals("Maintenance"))) {
			if (id.contains("C_")) {
				car = new Car();
				car.completeMaintenance(vehicleID,cDate);
			} else {
				van = new Van();
				van.completeMaintenance(vehicleID,cDate);
			}
		}
		}finally {
			
		}
	}
	
}
