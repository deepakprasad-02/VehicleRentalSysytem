package main;


import controller.DialogCancelController;
import controller.ExportController;
import controller.QuitButtonController;
import dao.VehicleDB;
import controller.ImportController;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.File;
import java.util.List;


import bean.VehicleBean;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.util.Callback;
import view.AddVehicleView;
import view.VehicleDetailView;

public class Main extends Application{
	
	public static void main(String[] args) {		
		ThriftyRentSystem trs=new ThriftyRentSystem();
		try {
			trs.startUp();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		launch(args);
	} 
		
	static class CustomCell extends ListCell<VehicleBean> {
        HBox hbox = new HBox();
        VehicleBean lastItem;
        ImageView imgView=new ImageView();
        
        Label label = new Label("(empty)");
        Pane pane = new Pane();
        Button button = new Button("View Details");
        

        public CustomCell() {
            super();
            hbox.getChildren().addAll(imgView,label, pane, button);
            HBox.setHgrow(pane, Priority.ALWAYS);
            button.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                   VehicleDetailView.detailView(lastItem);	
                }
            });
        }

        @Override
        protected void updateItem(VehicleBean item, boolean empty) {
            super.updateItem(item, empty);
            setText(null);  
            if (empty) {
                lastItem = null;
                setGraphic(null);
            } else {
                lastItem = item;
                label.setText(item!=null ? item.getDetails() : "<null>");
                imgView.setImage(new Image(new File("Images/"+item.getImageName()).toURI().toString(),100, 100, false, false));
                setGraphic(hbox);
            }
        }
    }
	
	@Override
	public void start(Stage primaryStage) throws Exception {
		Stage window=primaryStage;
		
		
		// create a menu 
        Menu m = new Menu("Menu"); 

        // create menuitems
		
		 MenuItem m1 = new MenuItem("Import to DB"); 
	        MenuItem m2 = new MenuItem("Export to File"); 
	        MenuItem m3 = new MenuItem("Quit"); 
	  
	        // add menu items to menu 
	        m.getItems().add(m1); 
	        m.getItems().add(m2); 
	        m.getItems().add(m3); 
	  
	     
	  
	        	// add event 
	        	m1.setOnAction(new ImportController());   
	        	m2.setOnAction(new ExportController()); 
	       		m3.setOnAction(new QuitButtonController(window)); 
	  
	        	// create a menubar 
	        	MenuBar mb = new MenuBar(); 
	  
	        	// add menu to menubar 
	        	mb.getMenus().add(m);
	        	VBox vb = new VBox(mb); 

	        	Button addVehicleButton=new Button("Add Vehicle");
	        	Button ExitButton=new Button("Exit");
	        	HBox h1box=new HBox();
	        	h1box.getChildren().addAll(addVehicleButton,ExitButton);
	        	h1box.setSpacing(20);
	        	
	        	ExitButton.setOnAction(new DialogCancelController(window));
	        	addVehicleButton.setOnAction(new AddVehicleView());
	        	
		
	        	VehicleDB vdb=new VehicleDB();
	        	List<VehicleBean> vList=vdb.getVehicles();

		        StackPane pane = new StackPane();
		        
		        ObservableList<VehicleBean> list = FXCollections.observableArrayList(vList);
		        ListView<VehicleBean> lv = new ListView<>(list);
		        lv.setCellFactory(new Callback<ListView<VehicleBean>, ListCell<VehicleBean>>() {
		            public ListCell<VehicleBean> call(ListView<VehicleBean> param) {
		                return new CustomCell();
		            }
		        });
		       
		        pane.getChildren().add(lv);
		        BorderPane borderPane = new BorderPane();
		        borderPane.setTop(vb);
		        borderPane.setCenter(h1box);
				borderPane.setBottom(pane);
				BorderPane.setAlignment(pane, Pos.CENTER);
				Scene scene = new Scene(borderPane, 600, 600);
				window.setScene(scene);
		        window.show();
		    }

}



