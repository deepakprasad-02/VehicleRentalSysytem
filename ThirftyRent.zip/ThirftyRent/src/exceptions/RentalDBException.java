package exceptions;

import java.sql.SQLException;

/*
 * This method is for handling the exceptions during the database operations of rental record 
 * 
 */
@SuppressWarnings("serial")
public class RentalDBException extends SQLException{
	public RentalDBException(String msg) {
		super(msg);
	}
}

