package exceptions;


/*
 * This method is for handling the exceptions in rental record class
 * 
 */
@SuppressWarnings("serial")
public class RentalException extends Exception{
	public RentalException(String msg) {
		super(msg);
	}
}
