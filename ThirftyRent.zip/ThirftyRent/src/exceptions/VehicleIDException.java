package exceptions;


/*
 * This method is for handling the exceptions pertaining to invalid vehicle Id's
 * 
 */
@SuppressWarnings("serial")
public class VehicleIDException extends Exception{
	
	public VehicleIDException(String errMsg) {
		super(errMsg);
		System.out.println(errMsg);
	}

}
