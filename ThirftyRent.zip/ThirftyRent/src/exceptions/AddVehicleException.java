package exceptions;


/*
 * This method is for handling the exceptions incurred during adding a new vehicle to the system
 * 
 */
@SuppressWarnings("serial")
public class AddVehicleException extends Exception{
public AddVehicleException(String msg) {
	super(msg);
}
}
