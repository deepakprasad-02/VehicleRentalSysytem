package exceptions;

/*
 * 
 * This method is for the exceptions during the vehicle maintenance operation
 */
@SuppressWarnings("serial")
public class VehicleMaintenanceException extends Exception{
		public VehicleMaintenanceException(String errMsg) {
			super(errMsg);
		}

}

