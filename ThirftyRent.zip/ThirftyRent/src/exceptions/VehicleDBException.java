package exceptions;

import java.sql.SQLException;

/*
 * This method is for handling the exceptions pertaining to vehicle DB operations
 * 
 */
@SuppressWarnings("serial")
public class VehicleDBException extends SQLException{
	
	public VehicleDBException(String errMsg) {
		super(errMsg);
		System.out.println(errMsg);
	}

}
