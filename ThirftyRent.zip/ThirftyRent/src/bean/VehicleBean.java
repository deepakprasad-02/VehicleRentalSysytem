package bean;

import util.DateTime;

/*
 * This class contains vehicle details as an object
 */
public class VehicleBean {
private String vehicleID;
private int year;
private String make;
private String model;
private int noOfSeats;
private String vehicleStatus;
private DateTime lastMaintDate;
private String imageName;
public String getImageName() {
	return imageName;
}
public void setImageName(String imageName) {
	this.imageName = imageName;
}
public DateTime getLastMaintDate() {
	return lastMaintDate;
}
public void setLastMaintDate(DateTime lastMaintDate) {
	this.lastMaintDate = lastMaintDate;
}
public String getVehicleType() {
	return vehicleType;
}
public void setVehicleType(String vehicleType) {
	this.vehicleType = vehicleType;
}
private String vehicleType;
public String getVehicleID() {
	return vehicleID;
}
public void setVehicleID(String vehicledID) {
	this.vehicleID = vehicledID;
}
public int getYear() {
	return year;
}
public void setYear(int year) {
	this.year = year;
}
public String getMake() {
	return make;
}
public void setMake(String make) {
	this.make = make;
}
public String getModel() {
	return model;
}
public void setModel(String model) {
	this.model = model;
}
public int getNoOfSeats() {
	return noOfSeats;
}
public void setNoOfSeats(int noOfSeats) {
	this.noOfSeats = noOfSeats;
}
public String getVehicleStatus() {
	return vehicleStatus;
}
public void setVehicleStatus(String vehicleStatus) {
	this.vehicleStatus = vehicleStatus;
}

/*
 * toString method to print details of a vehicle when the 
 * object is printed
 */
public String toString() {
	return returnString();
}
private String returnString() {
	String string=getVehicleID()+":"+getYear()+":"+getMake()+":"+getModel()+":"
			+getNoOfSeats()+":"+getVehicleStatus();
	if(getVehicleType().equalsIgnoreCase("van")) {
		string=string.concat(":"+getLastMaintDate());
	}
	string=string.concat(":"+getImageName());
	return string;
}


public String getDetails() {
	String string="Vehicle ID:\t\t"+getVehicleID()+"\nYear:\t\t\t"+getYear()+
			"\nMake:\t\t\t"+getMake()+"\nModel:\t\t\t"+getModel()+"\nNumber of seats:\t"
			+getNoOfSeats()+"\nStatus:\t\t\t"+getVehicleStatus();
	if(getVehicleType().equals("van")) {
		string=string.concat("\nLast Maintenance Date:\t"+getLastMaintDate());
	}
	return string;
}
}
