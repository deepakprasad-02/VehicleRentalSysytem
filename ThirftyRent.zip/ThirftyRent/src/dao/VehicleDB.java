package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import bean.VehicleBean;
import util.DBUtil;
import util.DateTime;

public class VehicleDB {

	/*
	 * This method is used for adding a single vehicle in to the database
	 * and returns true or false depending on the DB transaction
	 */
	@SuppressWarnings("finally")
	public boolean addVehicle(VehicleBean vBean) throws SQLException{
		boolean flag=false;
		Connection connection = DBUtil.getDBConnection();
		String query = "insert into vehicle(vehicleid,year,make,model,noofseats,vehicletype,status,lastmaintdate,imagename) values(?,?,?,?,?,?,?,?,?)";
		try {
			PreparedStatement prepare = connection.prepareStatement(query);
			prepare.setString(1, vBean.getVehicleID());
			prepare.setInt(2, vBean.getYear());
			prepare.setString(3, vBean.getMake());
			prepare.setString(4, vBean.getModel());
			prepare.setInt(5, vBean.getNoOfSeats());
			prepare.setString(6, vBean.getVehicleType());
			prepare.setString(7, vBean.getVehicleStatus());
			Long date=vBean.getLastMaintDate().getTime();
			prepare.setLong(8, date);
			prepare.setString(9, vBean.getImageName());
			int count = prepare.executeUpdate();
			if (count != 0) {
				flag=true;
			}
		} finally {
		return flag;
		}
	}
	
	/*
	 * This method is used to check the vehicleID in DB
	 * returns true or false based on the availability
	 * 
	 */
	public boolean checkVehicleID(String id) {
		boolean flag=false;
		Connection connection = DBUtil.getDBConnection();
		String query = "select * from vehicle  where vehicleid=?";
		try {
			PreparedStatement prepare = connection.prepareStatement(query);

			prepare.setString(1, id);
			ResultSet result = prepare.executeQuery();
			while (result.next()) {
				if((result.getString("vehicleID")).equalsIgnoreCase(id)) {
					flag=true;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return flag;		
	}
	
	/*
	 * This method returns the current status of the vehicle
	 */
	public String getVehicleStatus(String id) {
		String status=null;
		Connection connection = DBUtil.getDBConnection();
		String query = "select status from vehicle  where vehicleid=?";
		try {
			PreparedStatement prepare = connection.prepareStatement(query);
			prepare.setString(1, id);
			ResultSet result = prepare.executeQuery();
			if (result.next()) {
					status=result.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return status;
	}
	
	/*
	 * This method is used to change the status of particular vehicle ID in vehicle
	 * array
	 * 
	 * 
	 */
	
	public void changeStatus(String id, String status) throws SQLException {
		
		Connection connection = DBUtil.getDBConnection();
		String query = "update vehicle set status=? where vehicleid=?";
		try {
			PreparedStatement prepare = connection.prepareStatement(query);
			prepare.setString(1, status);
			prepare.setString(2, id);
			prepare.executeUpdate();
			
		}finally {
		}
	}
	
	/*
	 * This method deletes all the vehicle entries before loading the data
	 */
	public void deleteAllVehicles() throws SQLException {
		Connection connection = DBUtil.getDBConnection();
		String query = "delete from vehicle";
		try {
			Statement stmt = connection.createStatement();
			 stmt.executeUpdate(query);	
		}finally {
		}
	}
	
	
	/*
	 * 
	 * This method returns the number of seats for car
	 */
	public int getSeater(String id) {
		int seats=0;
		Connection connection = DBUtil.getDBConnection();
		String query = "select noOfseats from vehicle  where vehicleid=?";
		try {
			PreparedStatement prepare = connection.prepareStatement(query);
			prepare.setString(1, id);
			ResultSet result = prepare.executeQuery();
			if (result.next()) {
					seats=result.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return seats;
	}
	
	/*
	 * This method is used to update the last maintenance day during completeMaintenance
	 */
	public boolean updateMaintenanceDate(String id, DateTime date) {
		boolean flag=false;
		Connection connection = DBUtil.getDBConnection();
		String query = "update vehicle set lastMaintDate=? where vehicleid=?";
		try {
			PreparedStatement prepare = connection.prepareStatement(query);
			Long mDate=date.getTime();
			prepare.setLong(1, mDate);
			prepare.setString(2, id);
			int count = prepare.executeUpdate();
			if (count != 0) {
				flag = true;
			}
		} catch (SQLException e) {

			e.printStackTrace();
		}
		
		return flag;
	}
	
	/*
	 * This method is used to return the list of all vehicles in the database
	 */
	@SuppressWarnings("finally")
	public List<VehicleBean> getVehicles() throws Exception{
		List<VehicleBean> aList=new ArrayList<>();
		Connection connection = DBUtil.getDBConnection();
		VehicleBean vBean=null;
		String query = "select * from vehicle";
		try {
			Statement prepare = connection.createStatement();

			ResultSet res = prepare.executeQuery(query);

			while (res.next()) {
				vBean=new VehicleBean();
				vBean.setVehicleID(res.getString("vehicleid"));
				vBean.setMake(res.getString("make"));
				vBean.setModel(res.getString("model"));
				vBean.setYear(res.getInt("year"));
				vBean.setVehicleStatus(res.getString("status"));
				vBean.setNoOfSeats(res.getInt("noOfSeats"));
				vBean.setVehicleType(res.getString("vehicletype"));
				DateTime mDate=new DateTime(res.getLong("lastmaintdate"));
				vBean.setLastMaintDate(mDate);
				vBean.setImageName(res.getString("imagename"));
				aList.add(vBean);
			} 
		}finally {
		return aList;
		}
	}
	
	public DateTime getLastMaintenanceDate(String id) {
		DateTime date=null;
		Connection connection = DBUtil.getDBConnection();
		String query = "select lastmaintdate from vehicle  where vehicleid=?";
		try {
			PreparedStatement prepare = connection.prepareStatement(query);
			prepare.setString(1, id);
			ResultSet result = prepare.executeQuery();
			if (result.next()) {
					date=new DateTime(result.getLong(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}
	
	
	public void importTODB(List<VehicleBean> list) throws Exception {
		int counter=0;
		Connection connection = DBUtil.getDBConnection();
		int count[]=null;
		String query = "insert into vehicle(vehicleid,year,make,model,noofseats,vehicletype,status,lastmaintdate,imagename) values(?,?,?,?,?,?,?,?,?)";
		try {
			PreparedStatement prepare = connection.prepareStatement(query);
			for(VehicleBean vBean : list) {	
			prepare.setString(1, vBean.getVehicleID());
			prepare.setInt(2, vBean.getYear());
			prepare.setString(3, vBean.getMake());
			prepare.setString(4, vBean.getModel());
			prepare.setInt(5, vBean.getNoOfSeats());
			prepare.setString(6, vBean.getVehicleType());
			prepare.setString(7, vBean.getVehicleStatus());
			Long date=vBean.getLastMaintDate().getTime();
			prepare.setLong(8, date);
			prepare.setString(9, vBean.getImageName());
			prepare.addBatch();
			}
			count = prepare.executeBatch();
			for(Integer i : count) {
				if(i!=0) {
					counter++;
				}
			}
			
		} finally {
			if(counter<count.length)
		throw new Exception(counter+" records failed to be added in vehicle");
		}
	}
}
