package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import bean.RentalRecordBean;
import exceptions.RentalDBException;
import util.DBUtil;
import util.DateTime;

public class RentalDB {
	
	/*
	 * This method is used for creating a new rental record in the database
	 * and returns true or false depending on the DB transaction
	 */
	@SuppressWarnings("finally")
	public boolean createRentalRecord(RentalRecordBean rBean) throws RentalDBException{
		boolean flag=false;
		Connection connection = DBUtil.getDBConnection();
		Long rentDate=rBean.getRentDate().getTime();
		Long estimatedReturnDate=rBean.getEstimatedReturnDate().getTime();
		String query = "insert into rental_record(recordid,rentdate,estimatedreturndate) values(?,?,?)";
		try {
			PreparedStatement prepare = connection.prepareStatement(query);
			prepare.setString(1, rBean.getRecordID());
			prepare.setLong(2, rentDate);
			prepare.setLong(3, estimatedReturnDate);
			int count = prepare.executeUpdate();
			if (count != 0) {
				flag=true;
			}
		} finally {
		return flag;
		}
	}
	
	/*
	 * This method deletes all the rental record entries before loading the data
	 */
	public void deleteAllRentals() throws SQLException {
		Connection connection = DBUtil.getDBConnection();
		String query = "delete from rental_record";
		try {
			Statement stmt = connection.createStatement();
			 stmt.executeUpdate(query);	
		}finally {
		}
	}
	
	/*
	 * This method is used for importing data in to database
	 * 
	 */
	public void importRentalToDB(List<RentalRecordBean> rList) throws SQLException {
		Connection connection = DBUtil.getDBConnection();
		int counter=0;
		int count[]=null;
		String query = "insert into rental_record(recordid,rentdate,actualreturndate,estimatedreturndate,rentalfee,latefee) values(?,?,?,?,?,?)";
		try {
			PreparedStatement prepare = connection.prepareStatement(query);
			for(RentalRecordBean rBean : rList) {
			prepare.setString(1, rBean.getRecordID());
			Long rentDate=rBean.getRentDate().getTime();
			Long estimatedReturnDate=rBean.getEstimatedReturnDate().getTime();
			Long actualDate=rBean.getActualReturnDate().getTime();
			prepare.setLong(3, actualDate);
			prepare.setLong(2, rentDate);
			prepare.setLong(4, estimatedReturnDate);	
			prepare.setDouble(5, rBean.getRentalFee());
			prepare.setDouble(6, rBean.getLateFee());
			prepare.addBatch();
			}
			count = prepare.executeBatch();
			for(Integer i : count) {
				if(i!=0)
				counter++;
			}
			
		} finally {
			if(counter<count.length) {
				throw new SQLException(counter + " failed to be added in rental records.");
			}
		}
	}
	
	/*
	 * This methods updates the rental record after the vehicle has been returned
	 * 
	 */
	@SuppressWarnings("finally")
	public boolean updateRentalRecord(RentalRecordBean rBean) throws RentalDBException{
		boolean flag=false;
		Long actualReturnDate=rBean.getActualReturnDate().getTime();
		Connection connection = DBUtil.getDBConnection();
		String query = "update rental_record set actualReturnDate=?,rentalFee=?,lateFee=? where recordid=?";
		try {
			PreparedStatement prepare = connection.prepareStatement(query);
			prepare.setLong(1, actualReturnDate);
			prepare.setDouble(2, rBean.getRentalFee());
			prepare.setDouble(3, rBean.getLateFee());
			prepare.setString(4, rBean.getRecordID());
			int count = prepare.executeUpdate();
			if (count == 0) {
				throw new RentalDBException("Rental record was updated in the database.");
			}
		} finally {
		return flag;
		}
	}
	
	/*
	 * This method returns the latest recordID based on vehicle id
	 */
	@SuppressWarnings("finally")
	public RentalRecordBean getRentalRecord(String id) throws RentalDBException{
		RentalRecordBean rBean=null;
		Connection connection = DBUtil.getDBConnection();
		String query = "select recordid,actualReturnDate,estimatedReturnDate,rentDate from rental_record desc";
		try {
			Statement prepare = connection.createStatement();
			ResultSet res = prepare.executeQuery(query);
			while (res.next()) {
				String rid=res.getString(1);
				if(rid.contains(id)) {
					rBean=new RentalRecordBean();
					rBean.setRecordID(rid);
					DateTime actualReturnDate=new DateTime(res.getLong(2));
					DateTime estimatedReturnDate=new DateTime(res.getLong(3));
					DateTime rentDate=new DateTime(res.getLong(4));
					rBean.setActualReturnDate(actualReturnDate);
					rBean.setEstimatedReturnDate(estimatedReturnDate);
					rBean.setRentDate(rentDate);
				}
			}
		}finally {
		return rBean;
		}
	}
	
	
	/*
	 * This method retrieves all the rental records and returns it as a list
	 * 
	 */
	@SuppressWarnings("finally")
	public List<RentalRecordBean> getAllRentalRecords() throws RentalDBException{
		List<RentalRecordBean> rList=new ArrayList<>();
		RentalRecordBean rBean=null;
		Connection connection = DBUtil.getDBConnection();
		String query = "select * from rental_record order by rentdate desc";
		try {
			Statement prepare = connection.createStatement();

			ResultSet res = prepare.executeQuery(query);

			while (res.next()) {
				rBean=new RentalRecordBean();
				rBean.setRecordID(res.getString("recordid"));
				DateTime rentDate=new DateTime(res.getLong(2));
				DateTime actualReturnDate=new DateTime(res.getLong(3));
				DateTime estimatedReturnDate=new DateTime(res.getLong(4));
				rBean.setRentDate(rentDate);
				rBean.setEstimatedReturnDate(estimatedReturnDate);
				rBean.setActualReturnDate(actualReturnDate);
				rBean.setRentalFee(res.getDouble("rentalfee"));
				rBean.setLateFee(res.getDouble("latefee"));						
				rList.add(rBean);
			}
		} finally {
		return rList;
		}
	}
}
