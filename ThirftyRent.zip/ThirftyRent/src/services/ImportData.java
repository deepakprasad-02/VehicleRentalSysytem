package services;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

import bean.RentalRecordBean;
import bean.VehicleBean;
import dao.RentalDB;
import dao.VehicleDB;
import util.DateTime;
/*
 * 
 * This class is used for adding the data in to the data base
 */
public class ImportData {
	
	public static void consumeFromFile(File file) throws Exception {
		RentalDB rdb;
		VehicleDB vdb;
		DateTime date=null;
		RentalRecordBean rBean;
		VehicleBean vBean;
		vdb=new VehicleDB();
		rdb=new RentalDB();
		List<VehicleBean> vehicleList=vdb.getVehicles();
		if(vehicleList.size()>1) {
			vdb.deleteAllVehicles();
			rdb.deleteAllRentals();
		}
		 Double fee=0.0;
		 Double lFee=0.0;
		 DateTime arDate=null;
		List<VehicleBean> vList=new ArrayList<>();
		List<RentalRecordBean> rList=new ArrayList<>();
		try(BufferedReader bufferedReader = new BufferedReader(new FileReader(file))) {  
		    String line = bufferedReader.readLine();
		    while(line != null) {
		        String temp[]=line.split(":");
		        String temp1[]=temp[0].split("_");
		        if(temp1.length==5) {
		        rBean=new RentalRecordBean();
		        rBean.setRecordID(temp[0]);
		        DateTime rDate=new DateTime(temp[1]);
		        rBean.setRentDate(rDate);
		        DateTime eDate=new DateTime(temp[2]);
		        rBean.setEstimatedReturnDate(eDate);
		        if(!temp[3].equals("none")) {
		        	arDate=new DateTime(temp[3]);
		        	rBean.setActualReturnDate(arDate); 
		        	fee= Double.parseDouble(temp[4]);
			        lFee=Double.parseDouble(temp[5]);
			        rBean.setRentalFee(fee);
			        rBean.setLateFee(lFee);		        
		        }else {
		        	rBean.setActualReturnDate(new DateTime(0L));
		        	rBean.setRentalFee(fee);
			        rBean.setLateFee(lFee);	
		        }
		        rList.add(rBean);
		        }else {
		        vBean=new VehicleBean();
		        vBean.setVehicleID(temp[0]);
		        int year=Integer.parseInt(temp[1]);
		        vBean.setYear(year);
		        vBean.setMake(temp[2]);
		        vBean.setModel(temp[3]);
		        int seat=Integer.parseInt(temp[4]);
		        vBean.setNoOfSeats(seat);
		        vBean.setVehicleStatus(temp[5]);
		        if(temp.length==8){
		        	 vBean.setVehicleType("van");	
		        	 date=new DateTime(temp[6]);
				     vBean.setLastMaintDate(date);
				     vBean.setImageName(temp[7]);
		        }
		        else {
		        	vBean.setVehicleType("car");
		        	vBean.setImageName(temp[6]);
		        	 date=new DateTime(0L);
				     vBean.setLastMaintDate(date);
		        }
		        vList.add(vBean);
		        }
		        line = bufferedReader.readLine();
		    }
		    vdb.importTODB(vList);
		    rdb.importRentalToDB(rList);
		    
		} 
	}

}
