package services;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import bean.RentalRecordBean;
import bean.VehicleBean;
import dao.RentalDB;
import dao.VehicleDB;

public class ExportData {
public static void writeToFile(File file) throws IOException,Exception {
	VehicleDB vdb=new VehicleDB();
	RentalDB rdb=new RentalDB();
	List<VehicleBean> vList=vdb.getVehicles();
	List<RentalRecordBean> rList=rdb.getAllRentalRecords();
	String fileName="/export_data.txt";
	String filePath=file.getPath().concat(fileName);
	
	BufferedWriter bw = null;
	FileWriter fw = null;
	
	fw = new FileWriter(filePath,false);
	bw = new BufferedWriter(fw);
	try {
	for(VehicleBean vBean : vList) {
	String line=vBean.toString();	
	bw.write(line+"\n");
		for(RentalRecordBean rBean : rList) {		
			String rLine=rBean.toString();
			if(rBean.getRecordID().startsWith(vBean.getVehicleID())) {	
				bw.write(rLine+"\n");
			}
		}
		bw.flush();
	}
	}finally {
		if (bw != null)
			bw.close();

		if (fw != null)
			fw.close();
	}
	
}
}
