package services;

import java.sql.SQLException;
import java.time.Year;

import bean.RentalRecordBean;
import bean.VehicleBean;
import dao.RentalDB;
import dao.VehicleDB;
import exceptions.AddVehicleException;
import exceptions.RentalException;
import exceptions.VehicleIDException;
import main.Vehicle;
import util.DateTime;
import util.VehicleUtil;

public class Van extends Vehicle {

	/*
	 * This method validates the user input for new vehicle addition and adds the
	 * van to array list if all the qualifying conditions are met
	 */
	
	VehicleBean vBean = new VehicleBean();
	protected RentalRecordBean rBean = new RentalRecordBean();
	
	public void validateAndAddVan(VehicleBean bean) throws AddVehicleException, VehicleIDException,Exception {
		boolean flag = false;
		String vehicleID = null;
		int year = 1900;
		
		VehicleDB vdb=new VehicleDB();
		try {
			vehicleID = bean.getVehicleID().toUpperCase();
	        vehicleID = validateVanID(vehicleID);
			if (vehicleID==null) {
				throw new VehicleIDException("Invalid Vehicle ID for van....vanID should start with V_");
			}		
			bean.setVehicleID(vehicleID);
			year = bean.getYear();
			if (!(year >= 1900 && year <= (Year.now().getValue()))) {
				throw new AddVehicleException("Year is incorrect....please enter a valid year");
			}
			int seat=bean.getNoOfSeats();
			if(seat!=15) {
				throw new AddVehicleException("Van should have 15 seats.");
			}
			bean.setVehicleStatus("Available");
			flag=true;
		}  finally {
			if (flag == true) {
				vdb.addVehicle(bean);
			}
			
		}
	}

	/*
	 * This method validates vehicleID for the new van addition and also generates
	 * new vehicleID if id is not provided Returns vehicleId for the new van
	 */
	public String validateVanID(String IdToCheck) throws VehicleIDException {
		String id = null;
		String generatedID = null;
		boolean check = false;
		VehicleDB vdb = new VehicleDB();
		if (!(IdToCheck.trim().isEmpty()) && (IdToCheck.startsWith("V_"))) {
			check=vdb.checkVehicleID(IdToCheck);
			if (check == true) {
				throw new VehicleIDException("This Vehicle ID already exsists...please try with another ID\n");
			} else {
				id = IdToCheck;
			}
		} else if (IdToCheck.trim().isEmpty()) {
			generatedID = VehicleUtil.generateID("van");
			id = generatedID;
		}
		return id;
	}

	/*
	 * This method checks for the conditions for the van to be rented If the
	 * conditions are met, rental record will be created and status of van will be
	 * changed to 'Rented'
	 */
	@Override
	public void rent(String vehicleID,String customerId, DateTime rentDate, int numOfRentDay) throws RentalException, SQLException{
		
		try {
		
		RentalDB rdb=new RentalDB();
		VehicleDB vdb=new VehicleDB();
		DateTime lastMaintDate = vdb.getLastMaintenanceDate(vehicleID);
		DateTime returnDate = new DateTime(rentDate, numOfRentDay);
		DateTime nextMaintDate = new DateTime(lastMaintDate, 12);
		int dDays = DateTime.diffDays(nextMaintDate, returnDate);
		boolean check = ((dDays >= 1) && (dDays < 12));
		if (check) {
			RentalRecordBean rBean = new RentalRecordBean();
			String rentalId = vehicleID + "_" + customerId + "_" + rentDate.getEightDigitDate();
			rBean.setRecordID(rentalId);
			rBean.setRentDate(rentDate);
			rBean.setEstimatedReturnDate(returnDate);
			rdb.createRentalRecord(rBean);
			vdb.changeStatus(vehicleID, "Rented");
			
		}
		else {
			throw new RentalException("Van cannot be rented due to the clashes with its maintenance.");
		}
		}finally {
			
		}
	}

	/*
	 * This method is used to get the last maintenance date of the van.
	 * 
	
	public DateTime getLastMaintenanceDate(String id) {
		DateTime date = null;
		for (VehicleBean v : vehicleArray) {
			if (v.getVehicleID().equalsIgnoreCase(id)) {
				date = v.getLastMaintDate();
				break;
			}
		}
		return date;
	} */

	/*
	 * This method performs all the required validation while returning a car
	 * 
	 * 
	 * NOTE : If the van is returned after 14 days which is maximum, late fee would
	 * be calculated on extra days as needed. This point was discussed with Dale.
	 */
	public void returnVehicle(String vehicleID,DateTime returnDate) throws SQLException {
		int rate=235;
		int lateRate=299;
		String id = vehicleID;
		RentalDB rdb = new RentalDB();
		RentalRecordBean rBean=rdb.getRentalRecord(id);
		double lateFee = 0.0;
		double rentFee = 0.0;
		int dateDif = DateTime.diffDays(returnDate, rBean.getRentDate());
		int actual = DateTime.diffDays(rBean.getEstimatedReturnDate(), rBean.getRentDate());
		rentFee = dateDif * rate;
		if (dateDif != actual) {
			int extraDays = DateTime.diffDays(returnDate, rBean.getEstimatedReturnDate());
			lateFee = extraDays * lateRate;
			rBean.setLateFee(lateFee);
		}
		rBean.setActualReturnDate(returnDate);
		rBean.setRentalFee(rentFee);
		rdb.updateRentalRecord(rBean);
		(new VehicleDB()).changeStatus(id, "Available");
		
	}

	/*
	 * 
	 * This method is used when maintenance option is choose for a van
	 */
	public void performMaintenance(String vehicleID) throws SQLException {
			VehicleDB vdb=new VehicleDB();
			vdb.changeStatus(vehicleID, "Maintenance");
	} 

	/*
	 * 
	 * This method is for completing the Maintenance for van
	 * early and late dates are not checked as the requirements were not clear, checked with dale on this
	 */
	@Override
	public void completeMaintenance(String vehicleID, DateTime completionDate) throws SQLException {
		VehicleDB vdb=new VehicleDB();
		vdb.changeStatus(vehicleID, "Available");
		vdb.updateMaintenanceDate(vehicleID, completionDate);
	}

}
