package services;

import java.sql.SQLException;
import java.time.Year;

import bean.RentalRecordBean;
import bean.VehicleBean;
import dao.RentalDB;
import dao.VehicleDB;
import exceptions.AddVehicleException;
import exceptions.RentalException;
import exceptions.VehicleIDException;
import main.Vehicle;
import util.DateTime;
import util.VehicleUtil;

public class Car extends Vehicle {


	/*
	 * This method validates the user input for new vehicle addition and adds the
	 * car to array list if all the qualifying conditions are met
	 */
	
	public void validateAndAddCar(VehicleBean bean) throws Exception{
		boolean flag = false;
		String vehicleID = null;
		VehicleDB vdb=new VehicleDB();
		int year = 1900;
		int noOfSeats = 0;
		try {
			vehicleID = bean.getVehicleID().toUpperCase();
			vehicleID = validateCarID(vehicleID);
			if (vehicleID == null) {
				throw new VehicleIDException("Car ID is not valid....Car ID should start with C_");
			}
			bean.setVehicleID(vehicleID);
			year = bean.getYear();
			if (!(year >= 1900 && year <= (Year.now().getValue()))) {
				throw new AddVehicleException("Year is incorrect....please enter a valid year");
			}
			noOfSeats = bean.getNoOfSeats();
			if (!(noOfSeats == 4 || noOfSeats == 7)) {
				throw new AddVehicleException("Car should have 4 or 7 seats");
			}
			bean.setVehicleStatus("Available");
			if(bean.getVehicleType().equalsIgnoreCase("van")) {
				throw new AddVehicleException(bean.getVehicleType()+" is incorrect vehicle type for a car.");
			}
			bean.setVehicleType("car");
			
			flag=true;
		}  finally {
			if (flag == true) {
				vdb.addVehicle(bean);
			}
		}
	}

	/*
	 * This method validates vehicleID for the new car addition and also generates
	 * new vehicleID if id is not provided Returns vehicleId for the new car
	 */
	public String validateCarID(String IdToCheck) throws VehicleIDException {

		String id = null;
		String generatedID = null;
		VehicleDB vdb=new VehicleDB();
		boolean check = false;
		if (!(IdToCheck.trim().isEmpty()) && (IdToCheck.startsWith("C_"))) {
			check = vdb.checkVehicleID(IdToCheck);
			if (check == true) {
				throw new VehicleIDException("This Vehicle ID already exsists...please try with another ID\n");
			} else {
				id = IdToCheck;
			}
		} else if (IdToCheck.trim().isEmpty()) {
			generatedID = VehicleUtil.generateID("car");
			id = generatedID;
		}
		return id;
	}

	/*
	 * This method checks for the conditions for the car to be rented If the
	 * conditions are met, rental record will be created and status of car will be
	 * changed to 'Rented'
	 */
	public void rent(String vehicleID,String customerId, DateTime rentDate, int rentalDays) throws RentalException, SQLException {
		boolean flag = false;
		RentalDB rdb=new RentalDB();
		VehicleDB vdb=new VehicleDB();
		String id = vehicleID;
		if ((rentalDays <= 14)) {
			String day = rentDate.getNameOfDay();
			if ((day.equalsIgnoreCase("Friday")) || (day.equalsIgnoreCase("saturday"))) {
				if (rentalDays >= 3) {
					flag = true;
				}
				else {
					throw new RentalException("Rental starting on friday or saturday should have minimum 3 days.");
				}
			} else if (rentalDays >= 2) {
				flag = true;
			}
			else {
				throw new RentalException("Minimum 2 days is required for car rental.");
			}
		}
		if (flag == true) {
			RentalRecordBean rBean = new RentalRecordBean();
			String rentalId = id + "_" + customerId.toUpperCase() + "_" + rentDate.getEightDigitDate();
			rBean.setRecordID(rentalId);
			rBean.setRentDate(rentDate);
			DateTime returnDate = new DateTime(rentDate, rentalDays);
			rBean.setEstimatedReturnDate(returnDate);
			rdb.createRentalRecord(rBean);
			vdb.changeStatus(id, "Rented");
		}
	}

	

	/*
	 * This method performs all the required validation while returning a car
	 * 
	 * 
	 * NOTE : If the car is returned after 14 days which is maximum, late fee would
	 * be calculated on extra days as needed. This point was discussed with Dale.
	 */
	public void returnVehicle(String vehicleID,DateTime returnDate) throws SQLException {

		String id = vehicleID;
		int rent4=78;
		int rent7=113;
		double late4=97.5;
		double late7=141.25;
		RentalDB rdb=new RentalDB();
		VehicleDB vdb=new VehicleDB();
		RentalRecordBean rBean=rdb.getRentalRecord(id);
		int noOfSeats = vdb.getSeater(id);
		double lateFee = 0.0;
		double rentFee = 0.0;
		int dateDif = DateTime.diffDays(returnDate, rBean.getRentDate());
		int actual = DateTime.diffDays(rBean.getEstimatedReturnDate(), rBean.getRentDate());
		int diff=actual-dateDif;
		if ((diff>=0) && (dateDif <= 14)) {
			if (noOfSeats == 4) {
				rentFee = dateDif * rent4;
			} else {
				rentFee = dateDif * rent7;
			}
		} else {
			int extraDays = DateTime.diffDays(returnDate,rBean.getEstimatedReturnDate());
			if (noOfSeats == 4) {
				rentFee = dateDif * rent4;
				lateFee = extraDays * late4;
			} else {
				rentFee = dateDif * rent7;
				lateFee = extraDays * late7;
			}
		}
		rBean.setActualReturnDate(returnDate);
		rBean.setRentalFee(rentFee);
		rBean.setLateFee(lateFee);
		rdb.updateRentalRecord(rBean);
		(new VehicleDB()).changeStatus(id, "Available");
	}

	/*
	 * 
	 * This method is used when mainteanance option is chosen for a car
	 */
	public void performMaintenance(String vehicleID) throws SQLException {
		VehicleDB vdb=new VehicleDB();
		vdb.changeStatus(vehicleID, "Maintenance");
	}

	/*
	 * 
	 * This method is for completing the Maintenance
	 */
	public void completeMaintenance(String vehicleID,DateTime completionDate) throws SQLException {
		VehicleDB vdb=new VehicleDB();
		vdb.changeStatus(vehicleID, "Available");
		vdb.updateMaintenanceDate(vehicleID, completionDate);
	}

}
